﻿namespace UserInterface
{
    partial class TableView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.table1 = new System.Windows.Forms.Label();
            this.table2 = new System.Windows.Forms.Label();
            this.table3 = new System.Windows.Forms.Label();
            this.table4 = new System.Windows.Forms.Label();
            this.table5 = new System.Windows.Forms.Label();
            this.table6 = new System.Windows.Forms.Label();
            this.table7 = new System.Windows.Forms.Label();
            this.table8 = new System.Windows.Forms.Label();
            this.table9 = new System.Windows.Forms.Label();
            this.table10 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.pbox_ChapeauLogo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_ChapeauLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // table1
            // 
            this.table1.BackColor = System.Drawing.Color.Green;
            this.table1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table1.Location = new System.Drawing.Point(24, 75);
            this.table1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.table1.Name = "table1";
            this.table1.Size = new System.Drawing.Size(77, 69);
            this.table1.TabIndex = 0;
            this.table1.Text = "Table 1";
            this.table1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.table1.Click += new System.EventHandler(this.label1_Click);
            // 
            // table2
            // 
            this.table2.BackColor = System.Drawing.Color.Green;
            this.table2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table2.Location = new System.Drawing.Point(120, 75);
            this.table2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.table2.Name = "table2";
            this.table2.Size = new System.Drawing.Size(74, 69);
            this.table2.TabIndex = 10;
            this.table2.Text = "Table 2";
            this.table2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.table2.Click += new System.EventHandler(this.table2_Click);
            // 
            // table3
            // 
            this.table3.BackColor = System.Drawing.Color.Green;
            this.table3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table3.Location = new System.Drawing.Point(207, 75);
            this.table3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.table3.Name = "table3";
            this.table3.Size = new System.Drawing.Size(76, 69);
            this.table3.TabIndex = 11;
            this.table3.Text = "Table 3";
            this.table3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.table3.Click += new System.EventHandler(this.table3_Click);
            // 
            // table4
            // 
            this.table4.BackColor = System.Drawing.Color.Green;
            this.table4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table4.Location = new System.Drawing.Point(300, 75);
            this.table4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.table4.Name = "table4";
            this.table4.Size = new System.Drawing.Size(79, 69);
            this.table4.TabIndex = 12;
            this.table4.Text = "Table 4";
            this.table4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.table4.Click += new System.EventHandler(this.table4_Click);
            // 
            // table5
            // 
            this.table5.BackColor = System.Drawing.Color.Green;
            this.table5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table5.Location = new System.Drawing.Point(402, 75);
            this.table5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.table5.Name = "table5";
            this.table5.Size = new System.Drawing.Size(83, 69);
            this.table5.TabIndex = 13;
            this.table5.Text = "Table 5";
            this.table5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.table5.Click += new System.EventHandler(this.table5_Click);
            // 
            // table6
            // 
            this.table6.BackColor = System.Drawing.Color.Green;
            this.table6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table6.Location = new System.Drawing.Point(24, 199);
            this.table6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.table6.Name = "table6";
            this.table6.Size = new System.Drawing.Size(77, 69);
            this.table6.TabIndex = 14;
            this.table6.Text = "Table 6";
            this.table6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.table6.Click += new System.EventHandler(this.table6_Click);
            // 
            // table7
            // 
            this.table7.BackColor = System.Drawing.Color.Green;
            this.table7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table7.Location = new System.Drawing.Point(119, 199);
            this.table7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.table7.Name = "table7";
            this.table7.Size = new System.Drawing.Size(75, 69);
            this.table7.TabIndex = 15;
            this.table7.Text = "Table 7";
            this.table7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.table7.Click += new System.EventHandler(this.table7_Click);
            // 
            // table8
            // 
            this.table8.BackColor = System.Drawing.Color.Green;
            this.table8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table8.Location = new System.Drawing.Point(207, 199);
            this.table8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.table8.Name = "table8";
            this.table8.Size = new System.Drawing.Size(74, 69);
            this.table8.TabIndex = 16;
            this.table8.Text = "Table 8";
            this.table8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.table8.Click += new System.EventHandler(this.table8_Click);
            // 
            // table9
            // 
            this.table9.BackColor = System.Drawing.Color.Green;
            this.table9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table9.Location = new System.Drawing.Point(300, 199);
            this.table9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.table9.Name = "table9";
            this.table9.Size = new System.Drawing.Size(79, 69);
            this.table9.TabIndex = 17;
            this.table9.Text = "Table 9";
            this.table9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.table9.Click += new System.EventHandler(this.label9_Click);
            // 
            // table10
            // 
            this.table10.BackColor = System.Drawing.Color.Green;
            this.table10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table10.Location = new System.Drawing.Point(402, 199);
            this.table10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.table10.Name = "table10";
            this.table10.Size = new System.Drawing.Size(83, 69);
            this.table10.TabIndex = 18;
            this.table10.Text = "Table 10";
            this.table10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.table10.Click += new System.EventHandler(this.table10_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(200, 319);
            this.exitButton.Margin = new System.Windows.Forms.Padding(2);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(94, 36);
            this.exitButton.TabIndex = 19;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // pbox_ChapeauLogo
            // 
            this.pbox_ChapeauLogo.Image = global::UserInterface.Properties.Resources.ChapeauLogo;
            this.pbox_ChapeauLogo.Location = new System.Drawing.Point(1, 0);
            this.pbox_ChapeauLogo.Margin = new System.Windows.Forms.Padding(1);
            this.pbox_ChapeauLogo.Name = "pbox_ChapeauLogo";
            this.pbox_ChapeauLogo.Size = new System.Drawing.Size(77, 43);
            this.pbox_ChapeauLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_ChapeauLogo.TabIndex = 20;
            this.pbox_ChapeauLogo.TabStop = false;
            // 
            // TableView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 389);
            this.Controls.Add(this.pbox_ChapeauLogo);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.table10);
            this.Controls.Add(this.table9);
            this.Controls.Add(this.table8);
            this.Controls.Add(this.table7);
            this.Controls.Add(this.table6);
            this.Controls.Add(this.table5);
            this.Controls.Add(this.table4);
            this.Controls.Add(this.table3);
            this.Controls.Add(this.table2);
            this.Controls.Add(this.table1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "TableView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Table Overview";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TableView_FormClosing);
            this.Load += new System.EventHandler(this.TableView_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_ChapeauLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label table1;
        private System.Windows.Forms.Label table2;
        private System.Windows.Forms.Label table3;
        private System.Windows.Forms.Label table4;
        private System.Windows.Forms.Label table5;
        private System.Windows.Forms.Label table6;
        private System.Windows.Forms.Label table7;
        private System.Windows.Forms.Label table8;
        private System.Windows.Forms.Label table9;
        private System.Windows.Forms.Label table10;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox pbox_ChapeauLogo;
    }
}